

public class Food extends Product{
    private String date;
    private char type;
    public Food(String name, String id, String date) {
        super(name, id);
        this.date = date;
        this.type = 'F';
    }
    public void checkinventory(){
        System.out.println(this.getName()+" - "+this.date);
    }
}
