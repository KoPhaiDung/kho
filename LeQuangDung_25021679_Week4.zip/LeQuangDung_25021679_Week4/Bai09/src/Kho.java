import java.util.ArrayList;
import java.util.List;

public class Kho <E extends Product> {
    private List<E> SanPham;
    private String LoaiKho;
    public Kho(String LoaiKho) {
        this.LoaiKho = LoaiKho;
        this.SanPham = new ArrayList<>();
    }
    public void NhapKho(E product){
        this.SanPham.add(product);
    }
    public void XuatKho(String id){
        boolean kt = false;
        for(int i = 0; i < this.SanPham.size(); i++) {
            String ids = this.SanPham.get(i).getId();
            if (ids.equals(id)) {
                Product k = this.SanPham.remove(i);
                kt = true;
                String s;
                if (k instanceof Food) s ="thuc pham";
                else s = "do dien tu";
                System.out.println("Xuat kho san pham "+k.getName()+" trong kho "+s+" id: "+k.getId());
            }
        }
        if (kt == false) {
            System.out.println("Khong tim thay san pham trong kho "+this.LoaiKho+" co id: "+id);
        }
    }
    public void KiemKe(){
        System.out.println("\nKho "+this.LoaiKho);
        if (this.SanPham.isEmpty()) {
            System.out.println("Kho trong");
        }
        else {
            for (E i : this.SanPham){
                i.checkinventory();
            }
        }
    }
}
