import java.util.Scanner;
public class Main {
    static void main(){
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        Kho<Electronics> KhoDoDienTu = new Kho<>("Do dien tu");
        Kho<Food> KhoThucPham = new Kho<>("Thuc pham");
        for(int i = 0; i < n; i++) {
            String[] input = scan.nextLine().split(" ");
            if (input[0].charAt(0) == 'E') {
                Electronics electronics = new Electronics(input[2], input[1],Integer.parseInt(input[3]));
                KhoDoDienTu.NhapKho(electronics);
            }
            else {
                Food food = new Food(input[2], input[1], input[3]);
                KhoThucPham.NhapKho(food);
            }
        }
       // KhoThucPham.XuatKho("P01");
       // KhoDoDienTu.XuatKho("P04");
        KhoThucPham.KiemKe();
        KhoDoDienTu.KiemKe();
    }
}

