public class Electronics extends Product{
    private int months;
    protected char type;
    public Electronics(String name, String id, int months){
        super(name, id);
        this.months = months;
        this.type = 'E';
    }
    public void checkinventory(){
        System.out.println(this.getName()+" - "+this.months+" months to expire");
    }
}
