public abstract class Product{
    private String name;
    private String id;
    protected Product(String name, String id){
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return this.name;
    }
    public String getId() {
        return this.id;
    }
    protected abstract void checkinventory();
}