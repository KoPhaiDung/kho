public class SmartSpeaker extends Hub implements canbesetLevel,wifi_acess{
    private int VollumeLevel;
    public SmartSpeaker(String type, String id, String name){
        super(type, id, name);
        this.VollumeLevel = 50;
    }
    public void setlevel(int newLevel){
        this.VollumeLevel = newLevel;
        System.out.println(this.getName()+" vollume level change to "+ newLevel);
    }
    public void SetupWifi(){
        System.out.println(this.getName()+" connected to wifi");
    }
}
