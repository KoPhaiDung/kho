public interface canbesetLevel {
    void setlevel(int newlevel );
}
