public interface wifi_acess {
    void SetupWifi();
}
