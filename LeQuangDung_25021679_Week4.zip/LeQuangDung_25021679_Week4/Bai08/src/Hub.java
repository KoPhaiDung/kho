import java.util.ArrayList;
import java.util.List;

public abstract class Hub {
    private String type;
    private String id;
    private String name;
    private boolean state;
    private static List<Hub> machines = new ArrayList<>();
    protected Hub(String type, String id, String name){
        this.type = type;
        this.id = id;
        this.name = name;
        this.state = true;
        machines.add(this);
    }
    protected String getName(){
        return this.name;
    }
    public void setState(){
        if (this.state == true) {
            System.out.println(this.name+ " turned off");
        }
        else System.out.println(this.name+ " turned on");
    }
    public static void turnAllOff(){
        for (Hub i : machines){
            i.setState();
        }
    }
}
