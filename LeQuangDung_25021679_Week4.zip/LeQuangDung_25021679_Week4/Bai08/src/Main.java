import java.util.Scanner;
public class Main {
    static void main(){
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        Hub[] machines = new Hub[n];
        for(int i = 0; i < n; i++){
            String[] input = scan.nextLine().split(" ");
            if (input[0].charAt(0) == 'L') {
                machines[i] = new SmartLight(input[0], input[1], input[2]);
            } else if (input[0].equals("AC")) {
                machines[i] = new AirConditioner(input[0], input[1], input[2]);
            } else if (input[0].charAt(0) == 'S') {
                machines[i] = new SmartSpeaker(input[0], input[1], input[2]);
            }
            else machines[i] = new AutoCurtain(input[0], input[1], input[2]);
        }
        Hub.turnAllOff();
        System.out.println("\nSetup Wifi:\n");
        for (int i = 0; i < n ; i++) {
            if (machines[i] instanceof SmartSpeaker || machines[i] instanceof AirConditioner) {
                ((wifi_acess)machines[i]).SetupWifi();
            }
        }
    }
}

