public class AutoCurtain extends Hub{
    public AutoCurtain(String type, String id, String name){
        super(type, id, name);
    }
}
