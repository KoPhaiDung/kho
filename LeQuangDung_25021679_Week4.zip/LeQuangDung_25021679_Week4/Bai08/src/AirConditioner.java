public class AirConditioner extends Hub implements wifi_acess{
    public AirConditioner(String type, String id, String name){
        super(type, id, name);
    }
    public void SetupWifi(){
        System.out.println(this.getName()+" connected to wifi");
    }
}
