public class SmartLight extends Hub implements canbesetLevel{
    private int LightLevel;
    public SmartLight(String type, String id, String name){
        super(type, id, name);
         this.LightLevel= 20;
    }
    public void setlevel(int newLevel){
        this.LightLevel = newLevel;
        System.out.println(this.getName()+"light level change to "+ newLevel);
    }
}
