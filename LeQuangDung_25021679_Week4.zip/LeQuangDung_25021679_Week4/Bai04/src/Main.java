public class Main {
    static void main() {
        DataManager data = new DataManager();
        data.show();
    }
}
/*  
    2.	Biên dịch. Lỗi gì xuất hiện?
        lỗi: show() in DataManager cannot implement show() in IData;
         attempting to assign weaker access privileges; was public
    3.	Sửa lỗi và giải thích tại sao.
        -   Sửa: Thêm public vào trước void show
        -   do method show() được cài đặt thông qua interface IData là dạng 1 bản hợp đồng công khai
        tức là mọi method đều là abstract với mức độ truy cập là public, khi đó việc override method
        của IData phải đảm bảo điều kiện tiên quyết của override 1 phương thức là mức độ truy cập phải
        lớn hơn hoặc bằng mức độ truy cập gốc được override
 */
