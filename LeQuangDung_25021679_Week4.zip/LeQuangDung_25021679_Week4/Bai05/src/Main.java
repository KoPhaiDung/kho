public class Main {
    static void main() {
        Pair<String, Integer> tuoi = new Pair<>("Tuổi", 20);
        Pair<String, String> msv = new Pair<>("Mã SV", "SV001");
        Pair<Integer, Double> locate = new Pair<>(105, 21.5);
        System.out.println(tuoi);
        System.out.println(msv);
        System.out.println(locate);
    }
    /*lỗi: java: incompatible types: cannot infer type arguments for Pair<>
    reason: inference variable K has incompatible bounds
      equality constraints: java.lang.Integer
      lower bounds: java.lang.String*/
}

