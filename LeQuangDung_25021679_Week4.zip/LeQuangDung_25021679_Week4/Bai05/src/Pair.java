import java.security.Key;

public class Pair<K, V>{
    private K key;
    private V value;
    public Pair(K key, V value){
        this.key = key;
        this.value = value;
    }
    public K getKey() {
        return key;
    }
    public V getValue() {
        return value;
    }
    public void setKey(K newkey) {
        key = newkey;
    }
    public void setValue(V newvalue) {
        value = newvalue;
    }
    public String toString(){
        return key+" - "+value;
    }

}
