public class Square extends Shape{
    public Square(int x, int y){
        super(x, y);
    }
    public void erase(){
        System.out.println("Xóa hình vuông tại ("+this.x+","+this.y+")");
    }
    public void draw(){
        System.out.println("Vẽ hình vuông tại ("+this.x+","+this.y+")");
    }
}