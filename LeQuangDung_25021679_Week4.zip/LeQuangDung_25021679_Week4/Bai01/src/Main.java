import java.util.Scanner;
import java.util.ArrayList;
public class Main {
    void main() {
        Shape circle = new Circle(20, 20);
        circle.moveTo(10, 20);
    }
}
