public class Circle extends Shape{
    public Circle(int x, int y){
        super(x, y);
    }
    public void erase(){
        System.out.println("Xóa hình tròn tại ("+this.x+","+this.y+")");
    }
    public void draw(){
        System.out.println("Vẽ hình tròn tại ("+this.x+","+this.y+")");
    }
}
