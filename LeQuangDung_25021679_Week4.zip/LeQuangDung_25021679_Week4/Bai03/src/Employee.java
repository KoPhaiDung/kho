public abstract class Employee implements IWorkable{
    private String id;
    private String name;
    private double baseSalary;
    protected Employee(String id, String name, double baseSalary){
        this.id = id;
        this.name = name;
        this.baseSalary = baseSalary;
    }
    public String getName(){
        return this.name;
    }
    public double getbaseSalary(){
        return this.baseSalary;
    }
    public String getId(){
        return this.id;
    }
    /*protected void work(){
        System.out.println("Is working...");
        ko nhất thiết phải gọi nếu class đc cài đặt là
        abstract class thì các class con dưới nó 1 bậc có the gọi lại
    }*/
    abstract protected double caculatePay();
}
