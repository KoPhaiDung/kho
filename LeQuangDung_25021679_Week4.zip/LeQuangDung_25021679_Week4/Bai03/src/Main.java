import java.util.Scanner;
import java.util.ArrayList;
public class Main {
    void main() {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine()); //nhập vào số lượng nhân viên
        Employee[] employees = new Employee[n];
        for(int i = 0; i < n; i++){
            String[] input = scanner.nextLine().split(" ");//cắt kiểu input thành các phần
            if (input[0].charAt(0) == 'O'){
                employees[i] = new OfficeWorker(input[1], input[2], Double.parseDouble(input[3]));
            }
            else employees[i] = new Technician(input[1], input[2], Double.parseDouble(input[3]), Double.parseDouble(input[4]));
        }
        for (Employee e : employees){
            System.out.println(e.getName()+" - Pay: "+e.caculatePay());
            e.work();
        }
    }
}
