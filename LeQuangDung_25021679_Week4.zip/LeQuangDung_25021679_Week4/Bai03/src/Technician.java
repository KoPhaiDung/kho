public class Technician extends Employee{
    private double overtimeHours;
    public Technician(String id, String name, double baseSalary, double overtimeHours){
        super(id, name, baseSalary);
        this.overtimeHours = overtimeHours;
    }
    @Override
    public void work() {
        System.out.println("Lắp đặt thiết bị");
    }
    public double caculatePay(){
        double money = this.getbaseSalary() + overtimeHours * 20000;
        return money;
    }
}
