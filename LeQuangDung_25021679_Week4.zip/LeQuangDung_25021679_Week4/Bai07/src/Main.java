import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        List<Student> students = new ArrayList<>();
        for(int i = 0; i < n; i++) {
            String[] input = scan.nextLine().split(" ");
            students.add(new Student(input[0], input[1], Float.parseFloat(input[2])));
        }
        System.out.println("After removing GPA < 5.0:");
        for(int i = 0; i < n; i++) {
            if (students.get(i).getGpa() >= 5.0) {
                System.out.println(students.get(i));
            }
        }
        students.sort((s1, s2) -> s1.getName().compareTo(s2.getName()));
        System.out.println("\nAfter sorting by name:");
        for(int i = 0; i < n; i++) {
            System.out.println(students.get(i));
        }
        Operation<Double> cong = (a, b) -> a + b;
        Operation<Double> tru = (a, b) -> a - b;
        Operation<Double> nhan = (a, b) -> a * b;
        Operation<Double> chia = (a, b) -> {
            if (b == 0) throw new ArithmeticException("Không thể chia cho 0");
            return a / b;
        };
        double num1 = 15.5;
        double num2 = 5.0;
        System.out.println("Số a = " + num1 + ", Số b = " + num2);
        System.out.println("Cộng: " + cong.execute(num1, num2));
        System.out.println("Trừ: " + tru.execute(num1, num2));
        System.out.println("Nhân: " + nhan.execute(num1, num2));
        System.out.println("Chia: " + chia.execute(num1, num2));
    }
}