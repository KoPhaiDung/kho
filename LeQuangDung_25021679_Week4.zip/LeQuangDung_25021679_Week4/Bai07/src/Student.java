public class Student {
    private String id = "";
    private String name = "";
    private String email = "";
    private float gpa = 0;public Student() {
        this.id = "Null";
        this.name = "Null";
        this.email = "Null";
        this.gpa = 0;
    }
    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.email = "Null";
        this.gpa = 0;
    }
    public Student(String id, String name, float gpa) {
        this.id = id;
        this.name = name;
        this.email = "Null";
        this.gpa = gpa;
    }
    public Student(Student a) {
        this.id = a.id;
        this.name = a.name;
        this.email = a.email;
        this.gpa = a.gpa;
    }
    public float getGpa() {
        return this.gpa;
    }
    public String getName() {
        return this.name;
    }
    public String setgpa(float add) {
        if (add >= 0 && add <= 10) {
            this.gpa = add;
            return "Gpa của học sinh " + this.name + " đã được sửa thành " + add;
        } else {
            return "Số điểm Gpa nhập vào là không hợp lệ";
        }
    }
    public String setName(String name) {
        this.name = name;
        return "Tên của học sinh đã được đổi thành " + name;
    }
    public String setemail(String email) {
        this.email = email;
        return "Email của học sinh đã được đổi thành " + email;
    }
    public String setid(String id) {
        this.id = id;
        return "Id của học sinh đã được đổi thành " + id;
    }
    public String toString() {
        return id + " " + name + " " + gpa;
    }
}