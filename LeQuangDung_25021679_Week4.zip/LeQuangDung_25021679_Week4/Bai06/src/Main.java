public class Main {
    static void main() {
        Integer[] inter = {5,1,3,2};
        String[] strin = {"Java", "C++", "Python"};
        ArrayUtils.sort(inter);
        ArrayUtils.sort(strin);
        for (int i : inter) {
            System.out.print(i+" ");
        }
        System.out.println("");
        for (String i : strin) {
            System.out.print(i+" ");
        }
    }
}

