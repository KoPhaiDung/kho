public final class ArrayUtils {
    public static <T> void swap(T[] array, int i, int j){
        T temp;
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    /*
        comparable ở đây có nghĩa là T là kiểu   ữ liệu so sánh được
        nguyên tắc hoạt động của toán tử .compareTo()
            |âm(<0)    | nếu đối tượng hiện tại nhỏ hơn đối tượng ss|
            |dương(>0) | nếu đối tượng hiện tại lớn hơn đối tương ss|
            |0         | nếu 2 đối tượng bằng nhau giống vs .equal()|
        đối với kiểu dữ liệu là xâu(String) thì hàm compareTo so sánh mã ascii theo thứ tự từ trái sang phải cho đến khi tìm được sự khác biệt
     */
    public static <T extends Comparable<T>> void sort(T[] array){
        boolean ifswap;
        for(int i = 0; i < array.length; i++){
            ifswap =  false;
            for(int j = i; j < array.length; j++){
                if (array[i].compareTo(array[j]) > 0) {
                    ArrayUtils.swap(array, i, j);
                    ifswap = true;
                }
            }
            if (ifswap == false) break;
        }
    }
}
