import java.util.Scanner;
import java.util.ArrayList;
public class Main {
    void main() {
        ActionCharacter a = new Hero();
        ((CanFly)a).fly();//CanFly a1 = (CanFly) a; a1.fly()
        //((CanSwim)a).swim();//CanSwim a1 = (CanSwim a; a1.swim()
        a.fight();
    }
}
