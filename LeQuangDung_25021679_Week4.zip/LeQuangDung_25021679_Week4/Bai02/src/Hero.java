public class Hero extends ActionCharacter implements CanSwim, CanFly{
    public void swim(){
        System.out.println("Hero is swimming");
    };
    public void fly(){
        System.out.println("Hero is flying");
    };
}
