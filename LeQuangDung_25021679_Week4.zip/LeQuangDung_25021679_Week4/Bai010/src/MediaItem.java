public abstract class MediaItem {
    private String id;
    private String name;
    private String author;
    protected MediaItem(String id, String name, String author){
        this.id = id;
        this.name = name;
        this.author = author;
    }
    public String getname(){
        return this.name;
    }
    public String getAuthor(){
        return this.author;
    }
    public abstract void checkitems();
}
