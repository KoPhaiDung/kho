import java.util.Scanner;
public class Main {
    static void main(){
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
        LibrarySection<MediaItem> Khuvucsach = new LibrarySection<>("Sach");
        LibrarySection<MediaItem> KhuvucDVD = new LibrarySection<>("DVD");
        for(int i = 0; i < n; i++) {
            String[] input = scan.nextLine().split(" ");
            if (input[0].charAt(0) == 'B') {
                MediaItem book = new Book(input[1], input[2], input[3], Integer.parseInt(input[4]));
                Khuvucsach.nhapkho(book);
            }
            else {
                MediaItem dvd = new DVDdisk(input[1], input[2], input[3], Integer.parseInt(input[4]));
                KhuvucDVD.nhapkho(dvd);
            }
        }
        Khuvucsach.kiemke();
        KhuvucDVD.kiemke();
    }
}

