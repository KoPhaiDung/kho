public class Book extends MediaItem{
    private int pageNumbers;
    public Book(String id, String name, String author, int pageNumbers){
        super(id, name, author);
        this.pageNumbers = pageNumbers;
    }
    public void checkitems(){
        System.out.println(this.getname()+" - "+this.getAuthor()+" - "+this.pageNumbers);
    }
}
