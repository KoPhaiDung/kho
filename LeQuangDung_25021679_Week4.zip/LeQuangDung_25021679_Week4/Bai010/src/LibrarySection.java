import java.util.ArrayList;
import java.util.List;

public class LibrarySection<E extends MediaItem> {
    private String LoaiKhuVuc;
    private List<E> Items;
    public LibrarySection(String loaiKhuVuc){
        this.LoaiKhuVuc = loaiKhuVuc;
        this.Items = new ArrayList<>();
    }
    public void nhapkho(E item){
        this.Items.add(item);
    }
    public void kiemke(){
        System.out.println("\n Khu vuc "+this.LoaiKhuVuc+":");
        if (this.Items.isEmpty()) {
            System.out.println("Kho trong");
        }
        else {
            for (E i : this.Items){
                i.checkitems();
            }
        }
    }
}
