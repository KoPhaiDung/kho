public class DVDdisk extends MediaItem{
    private double duration;
    public DVDdisk(String id, String name, String author, double duration){
        super(id, name, author);
        this.duration = duration;
    }
    public void checkitems(){
        System.out.println(this.getname()+" - "+this.getAuthor()+" - "+this.duration);
    }
}
