import java.util.Scanner;
public class Main {
public static void main() {
    Scanner scan = new Scanner(System.in);
    System.out.println("Xin vui lòng nhập thông tin của sản phẩm 1 theo định dạng: ");
    System.out.println("Tên sản phẩm-Giá thành-Số lượng-Giảm giá");
    String[] l1 = scan.nextLine().split("-");
    Product p1 = new Product(l1[0], Double.parseDouble(l1[1]), Integer.parseInt(l1[2]), Double.parseDouble(l1[3]));
    System.out.println("Xin vui lòng nhập thông tin của sản phẩm 2 theo định dạng: ");
    System.out.println("Tên sản phẩm-Giá thành-Số lượng-Giảm giá");
    String[] l2 = scan.nextLine().split("-");
    Product p2 = new Product(l2[0], Double.parseDouble(l2[1]), Integer.parseInt(l2[2]), Double.parseDouble(l2[3]));
    System.out.println("Xin vui lòng nhập số lượng cần mua của sản phẩm 1: ");
    int am1 = scan.nextInt();
    p1.sell(am1);
    System.out.println("Xin vui lòng nhập số lượng cần mua của sản phẩm 2: ");
    int am2 = scan.nextInt();
    p2.sell((am2));
    System.out.println("Giá của sản phẩm:");
    System.out.println(p1.getname()+" : "+p1.calculateFinalPrice()+"$");
    System.out.println(p2.getname()+" : "+p2.calculateFinalPrice()+"$");
    p1.updateDiscount(10.0);
    System.out.println("Giá của sản phẩm sau giảm giá:");
    System.out.println(p1.getname()+" : "+p1.calculateFinalPrice()+"$");
    System.out.println(p2.getname()+" : "+p2.calculateFinalPrice()+"$");
    System.out.println("Tổng doanh thu: "+ Product.totalRevenue);
}}