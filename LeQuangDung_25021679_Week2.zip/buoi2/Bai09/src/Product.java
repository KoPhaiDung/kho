public class Product {
    private String name;
    private double price;
    private int quality;
    private double discount;
    public static double taxRate = 0.1;
    public static double totalRevenue = 0;
    public Product(String n, double pr, int q, double d){
        this.name = n;
        this.price = pr;
        this.quality = q;
        this.discount = d;
    }
    String getname(){
        return this.name;
    }
    static void updateTaxRate(double newRate){
        taxRate = newRate;
    }
    public double calculateFinalPrice(){
        double finalPrice = (price - discount) * (1 + taxRate);
        return finalPrice;
    }
    void updateDiscount(double newDiscount){
        this.discount = newDiscount;
    }
    void sell(int amount){
        if (this.quality >= amount){
            this.quality -= amount;
            totalRevenue  += amount * this.calculateFinalPrice();
            System.out.println("\nXuất kho thành công");
        }
        else System.err.println( "\nKhông đủ hàng trong kho");
    }
}

