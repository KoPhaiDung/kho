public class BankAccount {
    private String accountNumber ;
    private double balance = 0.0;
    private String ownerName;
    public String Constructor(String aN,double bl,String oN){
        this.accountNumber = aN;
        if (bl > 0){
            this.balance = bl;
        }
        else return "That shit bro!";
        this.ownerName = oN;
        return " ";
    }
    public void Constructor(String aN,String oN){
        this.accountNumber = aN;
        this.ownerName = oN;
        this.balance = 0.0;
    }
    public void deposit(float add){
        this.balance += add;
    }
    public Boolean withdraw(float add){
        if (add <= this.balance){
            this.balance -= add;
            return true;
        }
        else{
            return false;
        }
    }
    public double getBalance(){
        return this.balance;
    }
}
