import java.util.Scanner;
public class Main {
    public static void main(String[] arg) {
        System.out.println("Hi there, please inpu id, name and balance");
        Scanner scan = new Scanner(System.in);
        BankAccount acc1 = new BankAccount();
        String line = scan.nextLine();
        String[] parts = line.split("\\s+");
        if (parts.length ==2){
            acc1.Constructor(parts[0],parts[1]);
        }
        else{
            int k = Integer.parseInt(parts[1]);
            acc1.Constructor(parts[0],(double)k,parts[2]);
        }
        System.out.println("Try:");
        System.out.println("0 to stop banking");
        System.out.println("1 to add money");
        System.out.println("2 to take money");
        while (true){
            int add = scan.nextInt();
            if (add == 0){
                System.out.println("Thank you!");
                break;
            } else if (add == 1) {
                int ex = scan.nextInt();
                if (ex > 0) {
                    acc1.deposit(ex);
                    System.out.println("The balance of the account now is " + acc1.getBalance());
                } else System.out.println("That shit bro! you can't add an negative number!");
            } else if (add == 2){
                int ex = scan.nextInt();
                if (acc1.withdraw(ex) == true){
                    System.out.println("The balance of the account now is "+acc1.getBalance());
                }
                else System.out.println("That shit bro! you can't take more than you have");
            }
            else System.out.println("That shit is wrong bro! who teach you do tht");
        }
    }
}

