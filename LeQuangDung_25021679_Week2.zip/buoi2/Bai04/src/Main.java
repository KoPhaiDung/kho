import java.util.Scanner;

public class Main{
public static void main(String[] args) {
    Employee emp1 = new Employee("dung",new MyDate(1, 1,2000));
    Employee emp2 = new Employee(emp1);
    emp1.birthday.setDate(2, 2, 2022);
    System.out.println(emp1.birthday.getDate());
    System.out.println(emp2.birthday.getDate());
}}