public class Employee{
    public String name; 
    public MyDate birthday;
    public Employee(String n, MyDate b){
        String n1 = new String(n);
        MyDate b1 = new MyDate(b.day, b.month, b.year);
        this.name = n1;
        this.birthday = b1;
    }
    public Employee(Employee a){
        String n1 = new String(a.name);
        MyDate b1 = new MyDate(a.birthday.day, a.birthday.month, a.birthday.year);
        this.name = n1;
        this.birthday = b1;
    }
}