public class MyDate{
    public int day, month, year;
    public MyDate(int d, int m, int y){
        this.day = d;
        this.month = m;
        this.year = y;
    }
    public void setDate(int d, int m, int y){
        this.day = d;
        this.month = m;
        this.year = y;
    }
    public String getDate(){
        return (this.day+"/"+this.month+"/"+this.year);
    }
}
