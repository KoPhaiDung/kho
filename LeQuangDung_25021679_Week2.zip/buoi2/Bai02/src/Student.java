public class Student {
    private long id = 0;
    private String name = "";
    private String email = "";
    private float gpa = 0;
    public Student(){
        this.id = 0;
        this.name = "Null";
        this.email = "Null";
        this.gpa = 0;
    }
    public Student(long i, String nm){
        this.id = i;
        this.name = nm;
        this.email = "Null";
        this.gpa = 0;
    }
    public Student(Student a){
        this.id =a.id;
        this.name = a.name;
        this.email = a.email;
        this.gpa = a.gpa;
    }
    public String setgpa(int add) {
        if (add > 0 || add < 4) {
            this.gpa = add;
            String s = "Gpa của học sinh " + this.name + " đã được sửa thành " + add;
            return s;
        } else return "Số điểm Gpa nhập vào là không hợp lệ";
    }
    public  String setName(String name) {
        this.name = name;
        return ("Tên của học sinh đã được đổi thành "+name);
    }
    public  String setemail(String name) {
        this.email = name;
        return ("Email của học sinh đã được đổi thành "+name);
    }
    public  String setid(long id) {
        this.id = id;
        return ("Id của học sinh đã được đổi thành "+id);
    }
}
