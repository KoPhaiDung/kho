import java.util.Scanner;
public class Main{
public static void main() {
    Student student1 = new Student();
    String k = "Nguyen Khanh Chi";
    Student student2 = new Student(21233234,k);
    Student student3 = new Student(student2);
    System.out.println(student2.setemail("Chi123@mm"));
    System.out.println(student2.setgpa(3));
    System.out.println(student3.setemail("chichichi@12323"));
    System.out.println(student3.setgpa(2));
}}