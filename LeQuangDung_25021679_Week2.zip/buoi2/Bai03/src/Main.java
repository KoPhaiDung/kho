import java.util.Scanner;
public class Main{
public static void main() {
    NumberWrapper n1 = new NumberWrapper(5);
    NumberWrapper n2 = new NumberWrapper(10);
    n1.swap(n1 , n2);
    System.out.println(n1.getValue());
    System.out.println(n2.getValue());
}}