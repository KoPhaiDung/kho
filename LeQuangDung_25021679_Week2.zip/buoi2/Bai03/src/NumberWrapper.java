public class NumberWrapper {
    private int value;
    public NumberWrapper(int value){
        this.value = value;
    }
    public int getValue(){
        return value;
    }
    public void setValue(int val){
        this.value = val;
    }
    public void swap(NumberWrapper a, NumberWrapper b){
        NumberWrapper temp = new NumberWrapper(a.value);
        a.setValue(b.value);
        b.setValue((temp.value));
    }
}
