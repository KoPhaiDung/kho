public class Inventory {
    protected Product[] item = new Product[100];
    public Inventory(Product[] initialItems){
        this.item = new Product[initialItems.length];
        for(int i = 0; i < 2; i++){
            this.item[i] = new Product("Null", initialItems[i].name, initialItems[i].price);
        }
    }
}
