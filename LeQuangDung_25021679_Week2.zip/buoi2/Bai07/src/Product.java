public class Product {
    private String id;
    public String name;
    public double price;
    public Product(String id, String name, double price){
        this.id = id;
        this.name = name;
        this.price = price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
}

