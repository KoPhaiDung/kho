public class Main{
public static void main() {
    Product[] arr = new Product[10];
    arr[0] = new Product("112","banh tao",2000.0);
    arr[1] = new Product("113","banh khoai",2500.0);
    Inventory kho = new Inventory(arr);
    arr[0].setPrice(5000);
    System.out.println(kho.item[0].price);
}}