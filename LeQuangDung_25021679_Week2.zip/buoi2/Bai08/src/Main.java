import java.util.Scanner;
public class Main{
public static void main(String[] args) {
    Person p = new Person("dung");
    p.setMe(p);
    p.getMe().setName();
    System.out.println(p.getName());
    p = null;
}}