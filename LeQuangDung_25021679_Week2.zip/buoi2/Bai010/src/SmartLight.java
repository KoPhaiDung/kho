public class SmartLight {
    private String id;
    private String name;
    private int brightness;
    public SmartLight(String id, String name, int brightness){
        this.id = id;
        this.name = name;
        this.brightness = brightness;
    }
    public SmartLight(String id, String name){
        this.id = id;
        this.name = name;
        this.brightness = 50;
    }
    public String getName(){
        return this.name;
    }
    public void setBrightness(int brightness) {
        this.brightness = brightness;
    }
    public int getBrightness() {
        return(this.brightness);
    }
    public void setBrightness(String prs){
        if(prs == "MAX"){
            this.setBrightness(100);
        } else if (prs == "MIN") {
            this.setBrightness(10);
        } else if (prs == "ECO") {
            this.setBrightness(30);
        }
    }
    void connectToHub(CentralHub hub){
        hub.registerDevice(this);
    }
}
