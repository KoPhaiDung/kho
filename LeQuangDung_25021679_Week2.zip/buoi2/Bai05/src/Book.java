import java.util.Objects;

public class Book {
    private String title;
    private String author;
    private double price;
    public Book(String tt, String au, double pr){
        this.title = tt;
        this.author = au;
        this.price = pr;
    }
    public Boolean equals(Book a){
        if (Objects.equals(this.title, a.title) == true && Objects.equals(this.author, a.author) && this.price == a.price){
            return true;
        }
        return false;
    }
}
