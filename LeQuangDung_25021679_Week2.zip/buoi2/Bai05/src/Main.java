public class Main{
public static void main() {
    Book book1 = new Book("abc","xyz",12);
    Book book2 = new Book("abc","xyz",12);
    System.out.println(book1.equals(book2));
    System.out.println(book1 == (book2));
}}