public class Main{
public static void main() {
    Account acc1 = new Account("101279", 5000);
    acc1.addTransaction(new Transaction("112",200,"12h46p"));
    acc1.addTransaction(new Transaction("113",120,"12h48p"));
    acc1.addTransaction(new Transaction("114",-250,"12h49p"));
    acc1.addTransaction(new Transaction("115",-750,"12h54p"));
    Transaction[] d = acc1.getHistory();
    d[2].amount = 999999;
    System.out.println(acc1.getBalance());
}}