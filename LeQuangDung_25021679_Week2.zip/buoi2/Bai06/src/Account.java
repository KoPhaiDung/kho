public class Account {
    private String accountId;
    private double balance;
    private  Transaction[] history = new Transaction[100];
    public Account(String id, double balance){
        this.accountId = id;
        this.balance = balance;
    }
    public int time = 0;
    public void addTransaction(Transaction t){
        this.history[time] = t;
        time++;
    }
    public Transaction[] getHistory(){
        Transaction[] k = new Transaction[100];
        for(int i = 0; i <= 3; i++){
            k[i] = new Transaction("true",this.history[i].amount,"true");
        }
        return k;
    }
    public double getBalance(){
        for(int i = 0; i <= 3; i++){
            this.balance += history[i].amount;
        }
        return this.balance;
    }
}
