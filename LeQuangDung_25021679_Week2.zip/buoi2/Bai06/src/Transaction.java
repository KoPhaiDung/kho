import java.util.Objects;

public class Transaction {
    private String  transactionId;
    protected double amount;
    private String timestamp;
    public  Transaction(String tr, double am, String ts){
        this.transactionId = tr;
        this.amount = am;
        this.timestamp = ts;
    }

}
