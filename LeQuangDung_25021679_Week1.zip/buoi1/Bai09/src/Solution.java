
public class Solution {
    public static long sumOfDigits(long n){
        long k = 0;
        while (n!=0){
            k = k + n % 10;
            n = (long) n/10;
        }
        return k;
    }

    static void main() {
        System.out.println(sumOfDigits(999999999));
    }
}