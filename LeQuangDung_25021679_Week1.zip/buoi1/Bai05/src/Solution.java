public class Solution {
    public static long gcd(long a, long b){
        if (a<b) {
            a = a ^ b;
            b = a ^ b;
            a = a ^ b;
        }
        if (a==0 || b==0){
            if (a>b) return a;
            else return b;
        }
        long c=0;
        while (b!=0) {
            c=a%b;
            a=b;
            b=c;
        }
        return a;
    }

    static void main() {
        System.out.println(gcd(84,40));
        System.out.println(gcd(24,30));
        System.out.println(gcd(1,1));
    }
}