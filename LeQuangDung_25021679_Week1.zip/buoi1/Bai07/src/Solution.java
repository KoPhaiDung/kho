
public class Solution {
    public static long reverse(long n){
        long k = 0;
        while (true){
            k = k + n % 10;
            n = (long) n/10;
            if (n == 0){
                break;
            }
            k = k * 10;
        }
        return k;
    }

    static void main() {
        System.out.println(reverse(12345));
        System.out.println(reverse(1234233));
        System.out.println(reverse(11544245));
        System.out.println(reverse(9292923));
    }
}