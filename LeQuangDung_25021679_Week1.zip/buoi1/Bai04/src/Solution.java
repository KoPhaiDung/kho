// Import your library
// Do not change the name of the Solution class
public class Solution {
    public static long fibonacci(long n) {
        if (n==0 || n==1){
            return n;
        }
        return fibonacci(n-1)+ fibonacci(n-2);
    }
    public static void main(String[] args) {
        for (int i = 1; i <= 7 ; i++){
             System.out.println(fibonacci(i));
        }
    }
} 