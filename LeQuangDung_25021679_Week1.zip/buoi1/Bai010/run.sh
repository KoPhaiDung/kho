ROOT_DIR=$(pwd)
SRC_DIR="$ROOT_DIR/src"
BUILD_DIR="$ROOT_DIR/build"

# Tạo thư mục build nếu chưa có
mkdir -p "$BUILD_DIR"

# Biên dịch file Solution.java và đưa file .class vào thư mục build
javac -d "$BUILD_DIR" "$SRC_DIR/Solution.java"

# Chạy class Solution từ thư mục build
java -cp "$BUILD_DIR" Solution