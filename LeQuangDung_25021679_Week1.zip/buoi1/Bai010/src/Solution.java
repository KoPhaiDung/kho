
public class Solution {
    public static int secondLargest(int[] a){
        int mx1=-99999,mx2=-99999;
        for(int i = 0; i < a.length; i++){
            if (a[i]>mx2){
                if (a[i]>mx1){
                    mx2=mx1;
                    mx1=a[i];
                } else if (a[i]!=mx1) {
                    mx2=a[i];
                }
            }
        }
        if (mx1 == mx2 || mx2 == -99999){
            return -1;
        }
        return mx2;
    }
    public static void main(String[] args) {
        int[] a = {1,2,3,4,5,6,6,5,4,3,3,3,4,7,7,7};
        int[] b = {-1,-2,-3};
        int[] c = {5};
        System.out.println(secondLargest(a));
        System.out.println(secondLargest(c));
    }
}