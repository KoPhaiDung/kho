import java.util.Scanner;
public class Solution {
    public static boolean isPrime(int a){
        for (int i = 2 ; i < Math.sqrt(a) + 1 ; i++){
            if (a % i == 0) {
                return false;
            }
        }
        return true;
    }
    static void main() {
        System.out.println("Xin vui lòng nhập số để kiểm tra: ");
        Scanner scan = new Scanner(System.in);
        int k = scan.nextInt();
        System.out.println(isPrime(k));
    }
}