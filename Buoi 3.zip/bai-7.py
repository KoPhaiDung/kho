xau=input()
if(len(xau)<=20):
    print("khong hop le")
else:print(xau[5], xau[9])