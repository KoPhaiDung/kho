import math as m
xau=input().split()
a,b,c=map(int,xau)
mn=min(a,b,c)
if(mn<=0 or a+c<b or a+b<c or c+a<b  or c+b<a):
    print('Khong phai 3 canh cua tam giac')
else:
    p=(a+b+c)/2
    s=m.sqrt(p*(p-a)*(p-b)*(p-c))
    print(format(s,'.1f'))