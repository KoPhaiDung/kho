a=input()
if(ord(a)<=90 and ord(a)>=65 or ord(a)>=97 and ord(a)<=122):
    print(a,'là kí tu alphabet')
else:print(a,'không phải là kí tự alphabet')