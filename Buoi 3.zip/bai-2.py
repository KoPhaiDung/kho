
bien=input().split()
a,b=map(int,bien)
r=a/2
s=a*b-r*r*3.14
f=format(int(s),'.2f')
print(f)