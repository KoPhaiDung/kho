def laythongtin(xau,vitri):
    kq=''
    for i in range(0,len(xau)):
        if(i==vitri):
            kq+=xau[i]
            vitri+=1
    return kq
ten=laythongtin(input(),12)
chi_so_truoc=int(laythongtin(input(),20))
chi_so_sau=int(laythongtin(input(),18))
tien=0
for i in range(1,chi_so_sau-chi_so_truoc+1):
    if(i<=50):
        tien+=1984
    elif(i<=100):
        tien+=2050
    elif(i<=200):
        tien+=2380
    elif(i<=300):
        tien+=2998
    elif(i<=400):
        tien+=3350
    elif(i>400):
        tien+=3460
print('Ho va ten:', ten)
print('Tien phai tra la:',format(tien*1.08,'.0f'))