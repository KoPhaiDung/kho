xau=input()
if(xau=="A"):
    print("'A' là đặc biệt")
else:
    print(chr(ord(xau)-1).lower())