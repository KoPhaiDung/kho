xau=input()
if(xau==xau.upper()):
    print(xau.lower())
else: print(xau.upper())